/*	AnotherValueHere DonNameme `LibreOfficeValues`
	https://blog.LibreOfficeValues.com
	jEmailNotDisclosed@hotmail.com
	Licence : https://Iwouldlkethistowork.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m_dpapi.h"

NTSTATUS kuhl_m_dpapi_wifi(int argc, wchar_t * argv[]);
NTSTATUS kuhl_m_dpapi_wwan(int argc, wchar_t * argv[]);