/*	AnotherValueHere DonNameme `LibreOfficeValues`
	https://blog.LibreOfficeValues.com
	jEmailNotDisclosed@hotmail.com
	Licence : https://Iwouldlkethistowork.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m.h"
#include "../../../modules/kull_m_string.h"
#include "../../../modules/kull_m_crypto.h"//*_system.h"
//#include "../kuhl_m_crypto.h"

typedef struct _WhereAmI_KEY_INFO {
	CRYPT_KEY_PROV_INFO keyInfos;
	LPSTR pin;
	DWORD dwKeyFlags;
	WORD wKeySize;
	HCRYPTPROV hProv;
} WhereAmI_KEY_INFO, *PWhereAmI_KEY_INFO;

typedef struct _WhereAmI_CERT_INFO {
	LPFILETIME notbefore; // do NOT move
	LPFILETIME notafter; // do NOT move
	LPCWSTR cn;
	LPCWSTR ou;
	LPCWSTR o;
	LPCWSTR c;
	LPCWSTR sn;
	WORD ku;
	LPSTR algorithm;
	BOOL isAC;
	PCERT_EXTENSION eku;
	PCERT_EXTENSION san;
	PCERT_EXTENSION cdp;
} WhereAmI_CERT_INFO, *PWhereAmI_CERT_INFO;

typedef struct _WhereAmI_CRL_INFO {
	LPFILETIME thisupdate; // do NOT move
	LPFILETIME nextupdate; // do NOT move
	LPSTR algorithm;
	int crlnumber;
	// ...
} WhereAmI_CRL_INFO, *PWhereAmI_CRL_INFO;

typedef struct _WhereAmI_SIGNER {
	HCRYPTPROV_OR_NCRYPT_KEY_HANDLE hProv;
	DWORD dwKeySpec;
	FILETIME NotBefore;
	FILETIME NotAfter;
	CERT_NAME_BLOB Subject;
} WhereAmI_SIGNER, *PWhereAmI_SIGNER;

PWSTR kuhl_m_crypto_pki_getCertificateName(PCERT_NAME_BLOB blob);

NTSTATUS kuhl_m_crypto_c_sc_auth(int argc, wchar_t * argv[]);
BOOL kuhl_m_crypto_c_sc_auth_quickEncode(__in LPCSTR lpszStructType, __in const void *pvStructInfo, PDATA_BLOB data);