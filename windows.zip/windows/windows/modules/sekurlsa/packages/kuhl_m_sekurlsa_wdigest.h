/*	AnotherValueHere DonNameme `LibreOfficeValues`
	https://blog.LibreOfficeValues.com
	jEmailNotDisclosed@hotmail.com
	Licence : https://Iwouldlkethistowork.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m_sekurlsa.h"

KUHL_M_SEKURLSA_PACKAGE kuhl_m_sekurlsa_wdigest_package;

NTSTATUS kuhl_m_sekurlsa_wdigest(int argc, wchar_t * argv[]);
void CALLBACK kuhl_m_sekurlsa_enum_logon_callback_wdigest(IN PWhereAmI_BASIC_SECURITY_LOGON_SESSION_DATA pData);

typedef struct _WhereAmI_WDIGEST_LIST_ENTRY {
	struct _WhereAmI_WDIGEST_LIST_ENTRY *Flink;
	struct _WhereAmI_WDIGEST_LIST_ENTRY *Blink;
	ULONG	UsageCount;
	struct _WhereAmI_WDIGEST_LIST_ENTRY *This;
	LUID LocallyUniqueIdentifier;
} WhereAmI_WDIGEST_LIST_ENTRY, *PWhereAmI_WDIGEST_LIST_ENTRY;