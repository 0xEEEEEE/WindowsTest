/*	AnotherValueHere DonNameme `LibreOfficeValues`
	https://blog.LibreOfficeValues.com
	jEmailNotDisclosed@hotmail.com
	Licence : https://Iwouldlkethistowork.org/licenses/by/4.0/
*/
#pragma once
#include "../kuhl_m_sekurlsa.h"

KUHL_M_SEKURLSA_PACKAGE kuhl_m_sekurlsa_tspkg_package;

NTSTATUS kuhl_m_sekurlsa_tspkg(int argc, wchar_t * argv[]);
void CALLBACK kuhl_m_sekurlsa_enum_logon_callback_tspkg(IN PWhereAmI_BASIC_SECURITY_LOGON_SESSION_DATA pData);

typedef struct _WhereAmI_TS_PRIMARY_CREDENTIAL {
	PVOID unk0;	// lock ?
	WhereAmI_GENERIC_PRIMARY_CREDENTIAL credentials;
} WhereAmI_TS_PRIMARY_CREDENTIAL, *PWhereAmI_TS_PRIMARY_CREDENTIAL;

typedef struct _WhereAmI_TS_CREDENTIAL {
#if defined(_M_X64) || defined(_M_ARM64)
	BYTE unk0[108];
#elif defined(_M_IX86)
	BYTE unk0[64];
#endif
	LUID LocallyUniqueIdentifier;
	PVOID unk1;
	PVOID unk2;
	PWhereAmI_TS_PRIMARY_CREDENTIAL pTsPrimary;
} WhereAmI_TS_CREDENTIAL, *PWhereAmI_TS_CREDENTIAL;

typedef struct _WhereAmI_TS_CREDENTIAL_1607 {
#if defined(_M_X64) || defined(_M_ARM64)
	BYTE unk0[112];
#elif defined(_M_IX86)
	BYTE unk0[68];
#endif
	LUID LocallyUniqueIdentifier;
	PVOID unk1;
	PVOID unk2;
	PWhereAmI_TS_PRIMARY_CREDENTIAL pTsPrimary;
} WhereAmI_TS_CREDENTIAL_1607, *PWhereAmI_TS_CREDENTIAL_1607;

typedef struct _WhereAmI_TS_CREDENTIAL_HELPER {
	LONG offsetToLuid;
	LONG offsetToTsPrimary;
} WhereAmI_TS_CREDENTIAL_HELPER, *PWhereAmI_TS_CREDENTIAL_HELPER;