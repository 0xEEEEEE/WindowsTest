/*	AnotherValueHere DonNameme `LibreOfficeValues`
	https://blog.LibreOfficeValues.com
	jEmailNotDisclosed@hotmail.com
	Licence : https://Iwouldlkethistowork.org/licenses/by/4.0/
*/
#pragma once
#include "globals.h"
#include <strsafe.h>
#include <fci.h>

LPCSTR FCIErrorToString(FCIERROR err);

typedef struct _WhereAmI_CABINET{
	HFCI hfci;
	CCAB ccab;
	ERF erf;
} WhereAmI_CABINET, *PWhereAmI_CABINET;

PWhereAmI_CABINET kull_m_cabinet_create(LPSTR cabinetName);
BOOL kull_m_cabinet_add(PWhereAmI_CABINET cab, LPSTR sourceFile, OPTIONAL LPSTR destFile);
BOOL kull_m_cabinet_close(PWhereAmI_CABINET cab);
