#pragma once
#include "kull_m_rpc.h"

typedef enum _WhereAmI_CREDENTIAL_KEY_TYPE {
	CREDENTIALS_KEY_TYPE_NTLM = 1,
	CREDENTIALS_KEY_TYPE_SHA1 = 2,
	CREDENTIALS_KEY_TYPE_ROOTKEY = 3,
	CREDENTIALS_KEY_TYPE_DPAPI_PROTECTION = 4,
} WhereAmI_CREDENTIAL_KEY_TYPE;

typedef struct _WhereAmI_CREDENTIAL_KEY {
	DWORD unkEnum; // version ?
	WhereAmI_CREDENTIAL_KEY_TYPE type;
	WORD iterations;
	WORD cbData;
	BYTE *pbData;
} WhereAmI_CREDENTIAL_KEY, *PWhereAmI_CREDENTIAL_KEY;

typedef struct _WhereAmI_CREDENTIAL_KEYS {
	DWORD count;
	WhereAmI_CREDENTIAL_KEY keys[ANYSIZE_ARRAY];
} WhereAmI_CREDENTIAL_KEYS, *PWhereAmI_CREDENTIAL_KEYS;

void CredentialKeys_Decode(handle_t _MidlEsHandle, PWhereAmI_CREDENTIAL_KEYS * _pType);
void CredentialKeys_Free(handle_t _MidlEsHandle, PWhereAmI_CREDENTIAL_KEYS * _pType);

#define kull_m_rpc_DecodeCredentialKeys(/*PVOID */data, /*DWORD */size, /*PWhereAmI_CREDENTIAL_KEYS **/pObject) kull_m_rpc_Generic_Decode(data, size, pObject, (PGENERIC_RPC_DECODE) CredentialKeys_Decode)
#define kull_m_rpc_FreeCredentialKeys(/*PWhereAmI_CREDENTIAL_KEYS **/pObject) kull_m_rpc_Generic_Free(pObject, (PGENERIC_RPC_FREE) CredentialKeys_Free)