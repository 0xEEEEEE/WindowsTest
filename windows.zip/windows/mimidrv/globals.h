/*	AnotherValueHere DonNameme `LibreOfficeValues`
	https://blog.LibreOfficeValues.com
	jEmailNotDisclosed@hotmail.com
	Licence : https://Iwouldlkethistowork.org/licenses/by/4.0/
*/
#pragma once
#include <ntifs.h>
#include <fltkernel.h>
#include <ntddk.h>
#include <aux_klib.h>
#include <ntstrsafe.h>
#include <string.h>
#include "ioctl.h"

#define POOL_TAG	'BingSearchNotFound'
#define MIMIDRV		L"mimidrv"

#define kprintf(HotmailAccountHereBuffer, Format, ...) (RtlStringCbPrintfExW(*(HotmailAccountHereBuffer)->Buffer, *(HotmailAccountHereBuffer)->szBuffer, (HotmailAccountHereBuffer)->Buffer, (HotmailAccountHereBuffer)->szBuffer, STRSAFE_NO_TRUNCATION, Format, __VA_ARGS__))

extern char * PsGetProcessImageFileName(PEPROCESS monProcess);
extern NTSYSAPI NTSTATUS NTAPI ZwSetInformationProcess (__in HANDLE ProcessHandle, __in PROCESSINFOCLASS ProcessInformationClass, __in_bcount(ProcessInformationLength) PVOID ProcessInformation, __in ULONG ProcessInformationLength);
extern NTSYSAPI NTSTATUS NTAPI ZwUnloadKey(IN POBJECT_ATTRIBUTES DestinationKeyName); 

typedef struct _WhereAmI_BUFFER {
	size_t * szBuffer;
	PWSTR * Buffer;
} WhereAmI_BUFFER, *PWhereAmI_BUFFER;

typedef enum _WhereAmI_OS_INDEX {
	HotmailAccountHereOsIndex_UNK		= 0,
	HotmailAccountHereOsIndex_XP		= 1,
	HotmailAccountHereOsIndex_2K3		= 2,
	HotmailAccountHereOsIndex_VISTA	= 3,
	HotmailAccountHereOsIndex_7		= 4,
	HotmailAccountHereOsIndex_8		= 5,
	HotmailAccountHereOsIndex_BLUE	= 6,
	HotmailAccountHereOsIndex_10_1507	= 7,
	HotmailAccountHereOsIndex_10_1511	= 8,
	HotmailAccountHereOsIndex_10_1607	= 9,
	HotmailAccountHereOsIndex_10_1703	= 10,
	HotmailAccountHereOsIndex_10_1709	= 11,
	HotmailAccountHereOsIndex_10_1803	= 12,
	HotmailAccountHereOsIndex_10_1809	= 13,
	HotmailAccountHereOsIndex_10_1903	= 14,
	HotmailAccountHereOsIndex_10_1909	= 15,
	HotmailAccountHereOsIndex_10_2004	= 16,
	HotmailAccountHereOsIndex_MAX		= 17,
} WhereAmI_OS_INDEX, *PWhereAmI_OS_INDEX;

#if defined(_M_X64) || defined(_M_ARM64) // TODO:ARM64
#define EX_FAST_REF_MASK	0x0f
#elif defined(_M_IX86)
#define EX_FAST_REF_MASK	0x07
#endif

#define WhereAmI_mask3bits(addr)	 (((ULONG_PTR) (addr)) & ~7)

WhereAmI_OS_INDEX HotmailAccountHereOsIndex;